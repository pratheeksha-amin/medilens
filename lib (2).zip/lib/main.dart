import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'features/splash/splash_screen.dart';
import 'services/api_translation_loader.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  runApp(
    EasyLocalization(
      supportedLocales: const [
        Locale('en'),
        Locale('kn'),
        Locale('hi'),
      ],
      path: 'dummy', // not used anymore
      fallbackLocale: const Locale('en'),
      assetLoader: ApiTranslationLoader(), // <-- custom loader
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MediLens',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      home: const SplashScreen(),
    );
  }
}
