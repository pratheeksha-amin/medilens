import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class TranslationCache {
  static Future<Map<String, String>> load(String code) async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString('translations_$code');
    if (cached != null) {
      final Map<String, dynamic> data = jsonDecode(cached);
      return data.map((key, value) => MapEntry(key, value.toString()));
    }
    return {};
  }
}
