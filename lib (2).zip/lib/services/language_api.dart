import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/language.dart';

class LanguageApi {
  static Future<List<Language>> getLanguages() async {
    final response = await http.get(
      Uri.parse("https://yourserver.com/api/languages"),
    );

    final List data = jsonDecode(response.body);
    return data.map((e) => Language.fromJson(e)).toList();
  }

  static Future<Map<String, String>> getTranslations(String code) async {
    final response = await http.get(
      Uri.parse("https://yourserver.com/api/translations?lang=$code"),
    );

    final Map<String, dynamic> data = jsonDecode(response.body);
    return data.map((key, value) => MapEntry(key, value.toString()));
  }
}
