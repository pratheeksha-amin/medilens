import 'package:flutter/material.dart';  // <-- this gives you Locale
import 'dart:convert';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApiTranslationLoader extends AssetLoader {
  @override
  Future<Map<String, dynamic>> load(String path, Locale locale) async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString('translations_${locale.languageCode}');

    if (cached != null) {
      return jsonDecode(cached);
    }

    // fallback: empty map if no translations found
    return {};
  }
}
