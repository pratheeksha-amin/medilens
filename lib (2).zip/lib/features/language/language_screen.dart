import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../services/language_api.dart';
import '../../models/language.dart';
import '../splash/splash_screen.dart';

class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Select Language")),
      body: FutureBuilder<List<Language>>(
        future: LanguageApi.getLanguages(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("No languages available"));
          }

          final languages = snapshot.data!;
          return ListView.builder(
            itemCount: languages.length,
            itemBuilder: (context, index) {
              final lang = languages[index];
              return ListTile(
                title: Text(lang.name),
                onTap: () async {
                  // 1. Fetch translations from API
                  final translations =
                  await LanguageApi.getTranslations(lang.code);

                  // 2. Save translations locally
                  final prefs = await SharedPreferences.getInstance();
                  prefs.setString(
                      'translations_${lang.code}', jsonEncode(translations));

                  // 3. Switch locale (reload EasyLocalization)
                  await context.setLocale(Locale(lang.code));

                  // 4. Navigate to Splash/Home
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const SplashScreen()),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
